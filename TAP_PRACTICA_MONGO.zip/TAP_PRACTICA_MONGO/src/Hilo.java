
import java.awt.Image;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;


public class Hilo extends Thread{
    NewJFrame puntero;
    int contador=1;
    String []imagenes={"1.jpg","2.jpg","3.png","4.png"};
    public Hilo(NewJFrame p){
        puntero=p;
    }
    @Override
    public void run(){
     //metodo que genera la ejecucion en segundo plano
     //este metodo solo se ejecuta una vez
     while(true){
        ImageIcon i =new ImageIcon(getClass().getResource(imagenes[contador]));
        ImageIcon ico=new ImageIcon(i.getImage().getScaledInstance(puntero.jLabel1.getWidth(), puntero.jLabel1.getHeight(), Image.SCALE_DEFAULT));
        puntero.jLabel1.setIcon(ico);
        contador++;
        if(contador==imagenes.length)contador=1;
         try {
             sleep(3000);
         } catch (InterruptedException ex) {
             Logger.getLogger(Hilo.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
    }
    
    
    
    
}
